

#import <Foundation/Foundation.h>

#pragma mark - EVL
static NSString *THD_INSTALL = @"THD_INSTALL";
static NSString *THD_APP_START = @"THD_INSTALL";

#pragma mark - UserDefaults
static NSString *TREVLFirstLaunchUserDefaultsKey = @"TREVLFirstLaunchUserDefaultsKey";
